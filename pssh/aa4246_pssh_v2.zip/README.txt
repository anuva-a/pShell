Atandrila Anuva
Project 1
aa4246 | 14317587

Compiling:
The following commands will start running the shell
$ make
$ ./pssh

Description:
Displays current directory within prompt. Command line arguments (such as: ls -l) are supported. Shell can be terminated with the "exit" command.
